<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class EquipoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            "equipoCodigo"=>$this->faker->bothify("???-###"),
            "nombre" => $this->faker->company . ' FC',
            "ciudad"=>$this -> faker->city(),
            'user_id' => User::factory(),
        ];
    }
}
