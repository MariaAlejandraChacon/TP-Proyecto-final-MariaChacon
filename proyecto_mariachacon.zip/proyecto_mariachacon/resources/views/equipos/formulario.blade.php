@extends('layouts.plantilla')
@section('titulo', 'Añadir Equipo')
@section('contenido')

    <h1>
        @isset($equipo)
            Editar
        @else
            Añadir
        @endisset
            Equipo
    </h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row">
        <div class="col-4">
            <form method="post" action="{{isset($equipo)? route('equipos.update', ['id'=>$equipo]) : route('equipos.store')}}">
                @isset($equipo)
                @method('put')
                @endisset
                @csrf
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="equipoCodigo" name="equipoCodigo" placeholder="equipoCodigo" value="{{ isset($equipo)? $equipo->equipoCodigo :old('equipoCodigo') }}">
                    <label for="floatingInput">ID Equipo</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombre" value="{{ isset($equipo)? $equipo->nombre :old('nombre') }}">
                    <label for="floatingInput">Nombre</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="ciudad" name="ciudad" placeholder="ciudad" value="{{ isset($equipo)? $equipo->ciudad :old('ciudad') }}">
                    <label for="floatingInput">Ciudad</label>
                </div>
                <input type="submit" value="Guardar" class="btn btn-primary">
                    <a href="{{ route('equipos.index') }}" class="btn btn-danger">Cancelar</a>
            </form>
        </div>
    </div>

@endsection

