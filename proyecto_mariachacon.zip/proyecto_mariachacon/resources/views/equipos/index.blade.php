@extends('layouts.plantilla')
@section('titulo', 'Lista de Equipos')
@section('contenido')

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #090909;
            text-align: center;
        }
    </style>

    <h1>Lista de Equipos
        @auth
        <a class="btn btn-info" href="{{route('jugadores.index')}}">Mostrar Jugadores</a>
        <a class="btn btn-success" href="{{route('equipos.create')}}">Nuevo Equipo</a>
        <a class="btn btn-success" href="{{route('jugadores.create')}}">Nuevo Jugador</a>
        @endauth
    </h1>

    @if(session()->has('status'))
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>¡Felicidades! </strong>{{session('status')}}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif
    <table class="table">
        <thead>
        <tr>
            <th>ID Equipo</th>
            <th>Nombre</th>
            <th>Ciudad</th>
            <th>Jugadores</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        @forelse($equipos as $equipo)
            <tr>
                <td>{{$equipo->equipoCodigo }}</td>
                <td>{{$equipo->nombre }}</td>
                <td>{{$equipo->ciudad }}</td>
                <td>
                    <span class="badge bg-primary">{{$equipo->jugadores->count()}}</span>
                </td>
                <td>
                    <a href="{{ route('equipos.show', ['id' => $equipo->id]) }}" class="btn btn-warning btn-sm">Descripción</a>
                    @auth
                    <a href="{{ route('equipos.edit', ['id'=> $equipo->id]) }}" class="btn btn-warning btn-sm">Editar</a>
                    @endauth

                    @auth
                    <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#eliminar_{{$equipo->id}}">Eliminar</button>
                    @endauth
                    <div class="modal fade" id="eliminar_{{$equipo->id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar equipo</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    ¿Desea realmente eliminar el equipo {{$equipo->nombre}}?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                    <form action="{{ route('equipos.destroy', ['id'=> $equipo->id]) }}" method="post">
                                        @csrf
                                        @method('delete')
                                        <input type="submit" value="Eliminar" class="btn btn-danger btn-sm">
                                    </form>
                                </div>
                            </div>
                        </div>
                </td>
            </tr>
        @empty
            <tr>
                <td colspan="5">No hay equipos registrados</td>
            </tr>
        @endforelse
        </tbody>
    </table>

    {{ $equipos->links() }}
@endsection
