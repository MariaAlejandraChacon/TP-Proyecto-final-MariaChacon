@extends('layouts.plantilla')

@section('titulo', 'Detalles del Equipo')

@section('contenido')
    {{-- Información del equipo --}}
    <h1>Detalles del Equipo {{ $equipo->nombre }}</h1>

    <ul>
        <li>ID: {{ $equipo->id }}</li>
        <li>Código de Equipo: {{ $equipo->equipoCodigo }}</li>
        <li>Nombre: {{ $equipo->nombre }}</li>
        <li>Ciudad: {{ $equipo->ciudad }}</li>
        <li>Fecha de Creación: {{ $equipo->created_at->diffForHumans() }}</li>
        <li>Fecha de Actualización: {{ $equipo->updated_at->diffForHumans() }}</li>
    </ul>

    <hr>

    {{-- Incluir la vista de jugadores --}}
    @include('jugadores.show', ['equipo' => $equipo])

    <a href="{{ route('equipos.index') }}" class="btn btn-primary">Volver a Lista de Equipos</a>
@endsection

