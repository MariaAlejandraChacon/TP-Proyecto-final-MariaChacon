
@extends('layouts.plantilla')
@section('titulo', isset($jugador) ? 'Editar Jugador' : 'Añadir Jugador')
@section('contenido')

    <h1>
        @isset($jugador)
            Editar
        @else
            Añadir
        @endisset
        Jugador
    </h1>

    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="{{ isset($jugador) ? route('jugadores.update', ['id' => $jugador->id]) : route('jugadores.store') }}">
                        @isset($jugador)
                            @method('put')
                        @endisset
                        @csrf
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre"
                                   value="{{ isset($jugador) ? $jugador->nombre : old('nombre') }}">
                            <label for="nombre">Nombre del Jugador</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="number" class="form-control" id="edad" name="edad" placeholder="Edad"
                                   value="{{ isset($jugador) ? $jugador->edad : old('edad') }}">
                            <label for="edad">Edad</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="posicion" name="posicion" placeholder="Posición"
                                   value="{{ isset($jugador) ? $jugador->posicion : old('posicion') }}">
                            <label for="posicion">Posición</label>
                        </div>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="equipo_id" name="equipo_id">
                                <option value="">-- Selecciona un equipo --</option>
                                @foreach($equipos as $equipo)
                                    <option value="{{ $equipo->id }}"
                                            @if((isset($jugador) && $jugador->equipo_id == $equipo->id) || old('equipo_id') == $equipo->id)
                                                selected
                                        @endif
                                    >
                                        {{ $equipo->nombre }}
                                    </option>
                                @endforeach
                            </select>
                            <label for="equipo_id">Equipo</label>
                        </div>

                            <button type="submit" class="btn btn-primary">{{ isset($jugador) ? 'Actualizar' : 'Guardar' }}</button>
                            <a href="{{ url()->previous() }}" class="btn btn-secondary">Cancelar</a>  {{-- Botón Cancelar modificado --}}
                    </form>
                </div>
            </div>
        </div>
    </div>

@endsection
```
