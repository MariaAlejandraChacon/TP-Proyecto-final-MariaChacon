<?php

use App\Http\Controllers\EquipoController;
use App\Http\Controllers\JugadorController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';

//Route::resource('equipos', \App\Http\Controllers\EquipoController::class);

Route::controller(EquipoController::class)->group(function () {
    Route::get('/equipos', 'index')->name('equipos.index');
    Route::get('/equipos/{id}', 'show')->name('equipos.show')->whereNumber('id');
    Route::get('/equipos/crear', 'create')->name('equipos.create')->middleware('auth');
    Route::post('/equipos/crear', 'store')->name('equipos.store')->middleware('auth');
    Route::get('/equipos/{id}/editar', 'edit')->name('equipos.edit')->whereNumber('id')->middleware('auth');
    Route::put('/equipos/{id}/editar', 'update')->name('equipos.update')->whereNumber('id')->middleware('auth');
    Route::delete('equipos/{id}/eliminar', 'destroy')->name('equipos.destroy')->whereNumber('id')->middleware('auth');
});

Route::controller(JugadorController::class)->group(function () {
    Route::get('/jugadores', 'index')->name('jugadores.index');
    Route::get('/jugadores/{id}', 'show')->name('jugadores.show')->whereNumber('id');
    Route::get('/jugadores/crear', 'create')->name('jugadores.create')->middleware('auth');
    Route::post('/jugadores/crear', 'store')->name('jugadores.store')->middleware('auth');
    Route::get('/jugadores/{id}/editar', 'edit')->name('jugadores.edit')->whereNumber('id')->middleware('auth');
    Route::put('/jugadores/{id}/editar', 'update')->name('jugadores.update')->whereNumber('id')->middleware('auth');
    Route::delete('/jugadores/{id}/eliminar', 'destroy')->name('jugadores.destroy')->whereNumber('id')->middleware('auth');
});
