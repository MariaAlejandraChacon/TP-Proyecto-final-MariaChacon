<?php

namespace App\Http\Controllers;

use App\Models\Equipo;
use App\Models\Jugador;
use Illuminate\Http\Request;

class JugadorController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $jugadores = Jugador::with('equipo')->paginate(10);
        return view('jugadores.index', compact('jugadores'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $equipos = Equipo::orderBy('nombre')->get(); // Ordenar equipos por nombre
        return view('jugadores.formulario', compact('equipos'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validación
        $validated = $request->validate([
            'nombre' => 'required|max:60|min:3',
            'edad' => 'required|integer|between:16,40',
            'posicion' => 'required|max:30',
            'equipo_id' => 'required|exists:equipos,id',
        ]);

        // Crear un nuevo objeto jugador
        $jugador = new Jugador();

        // Asignar los valores a los campos
        $jugador->nombre = $request->input('nombre');
        $jugador->edad = $request->input('edad');
        $jugador->posicion = $request->input('posicion');
        $jugador->equipo_id = $request->input('equipo_id');

        // Guardar en la base
        $resultado = $jugador->save();

        // Si guardó bien... comunicarle al usuario que se logró guardar
        if ($resultado){
            return redirect()->route('jugadores.index') // Redirige a la lista de jugadores
            ->with('status', 'Jugador registrado correctamente');
        } else {
            return back()->withInput()
                ->with('error', 'Error al guardar el jugador');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $equipos = Equipo::withCount('jugadores')->get();

        return view('jugadores.index', compact('equipos'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $jugador = Jugador::findOrFail($id);
        $equipos = Equipo::orderBy('nombre')->get();
        return view('jugadores.formulario', compact('jugador', 'equipos'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // Recuperar de la base el jugador existente
        $jugador = Jugador::findOrFail($id);

        // Validación
        $validated = $request->validate([
            'nombre' => 'required|max:60|min:3',
            'edad' => 'required|integer|between:16,40',
            'posicion' => 'required|max:30',
            'equipo_id' => 'required|exists:equipos,id',
        ]);

        // Asignar los cambios en los campos
        $jugador->nombre = $request->input('nombre');
        $jugador->edad = $request->input('edad');
        $jugador->posicion = $request->input('posicion');
        $jugador->equipo_id = $request->input('equipo_id');

        // Guardar
        $resultado = $jugador->save();

        // Si guardó bien... comunicarle al usuario que se logró guardar
        if ($resultado){
            return redirect()->route('jugadores.index')
                ->with('status', 'Jugador editado correctamente');
        } else {
            return back()->withInput()
                ->with('error', 'Error al actualizar el jugador');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $jugador = Jugador::findOrFail($id);
        $nombreJugador = $jugador->nombre;
        $idEquipo = $jugador->equipo_id;

        $borrado = $jugador->delete();

        if ($borrado) {
            // Si venimos de la vista de equipo, redirigir de vuelta a ella
            if (url()->previous() == route('equipos.show', ['id' => $idEquipo])) {
                return redirect()->route('equipos.show', ['id' => $idEquipo])
                    ->with('status', "Jugador '$nombreJugador' eliminado correctamente");
            }

            return redirect()->route('jugadores.index')
                ->with('status', "Jugador '$nombreJugador' eliminado correctamente");
        } else {
            return redirect()->route('jugadores.index')
                ->with('error', 'No se pudo eliminar el jugador');
        }
    }
}
