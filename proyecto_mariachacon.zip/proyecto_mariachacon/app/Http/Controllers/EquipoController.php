<?php

namespace App\Http\Controllers;

use App\Models\Equipo;
use App\Models\Jugador;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EquipoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $equipos = Equipo::with('jugadores')->paginate(10);
        return view('equipos.index', compact('equipos'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('equipos.formulario');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Validación
        $validated = $request->validate([
            'equipoCodigo' => ['required', 'unique:equipos', 'max:8', 'min:5'],
            'nombre' => 'required|max:60|min:4',
            'ciudad' => 'required|max:60|min:4'
        ]);

        // Crear un nuevo objeto equipo
        $equipo = new Equipo();

        // Asignar los valores a los campos
        $equipo->nombre = $request->input('nombre');
        $equipo->equipoCodigo = $request->input('equipoCodigo');
        $equipo->ciudad = $request->input('ciudad');
        $equipo->user_id = Auth::id() ?? 1; // Usar Auth::id() si está disponible, o 1 como fallback

        // Guardar en la base
        $resultado = $equipo->save();

        // Si guardo bien... comunicarle al usuario que se logró guardar
        if ($resultado){
            return redirect()->route('equipos.index')
                ->with('status', 'Equipo registrado correctamente');
        } else {
            return back()->withInput()
                ->with('error', 'Error al guardar el equipo');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $equipo = Equipo::with('jugadores')->findOrFail($id);
        return view('equipos.show', compact('equipo'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $equipo = Equipo::findOrFail($id);
        return view('equipos.formulario', compact('equipo'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        // Recuperar de la base el equipo existente
        $equipo = Equipo::findOrFail($id);

        // Validación
        $validated = $request->validate([
            'equipoCodigo' => ['required', 'max:8', 'min:5', 'unique:equipos,equipoCodigo,'.$equipo->id],
            'nombre' => 'required|max:60|min:4',
            'ciudad' => 'required|max:60|min:4'
        ]);

        // Asignar los cambios en los campos
        $equipo->nombre = $request->input('nombre');
        $equipo->equipoCodigo = $request->input('equipoCodigo');
        $equipo->ciudad = $request->input('ciudad');

        // Guardar
        $resultado = $equipo->save();

        // Si guardo bien... comunicarle al usuario que se logró guardar
        if ($resultado){
            return redirect()->route('equipos.index')
                ->with('status', 'Equipo editado correctamente');
        } else {
            return back()->withInput()
                ->with('error', 'Error al actualizar el equipo');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $equipo = Equipo::findOrFail($id);

        // Verificar si el equipo tiene jugadores
        if ($equipo->jugadores()->count() > 0) {
            return redirect()->route('equipos.index')
                ->with('error', 'No se puede eliminar un equipo con jugadores');
        }

        $borrado = $equipo->delete();

        if ($borrado) {
            return redirect()->route('equipos.index')
                ->with('status', 'Equipo eliminado correctamente');
        } else {
            return redirect()->route('equipos.index')
                ->with('error', 'No se pudo eliminar el equipo');
        }
    }
}
