<?php $__env->startSection('titulo', 'Añadir Equipo'); ?>
<?php $__env->startSection('contenido'); ?>

    <h1>
        <?php if(isset($equipo)): ?>
            Editar
        <?php else: ?>
            Añadir
        <?php endif; ?>
            Equipo
    </h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-4">
            <form method="post" action="<?php echo e(isset($equipo)? route('equipos.update', ['id'=>$equipo]) : route('equipos.store')); ?>">
                <?php if(isset($equipo)): ?>
                <?php echo method_field('put'); ?>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="equipoCodigo" name="equipoCodigo" placeholder="equipoCodigo" value="<?php echo e(isset($equipo)? $equipo->equipoCodigo :old('equipoCodigo')); ?>">
                    <label for="floatingInput">ID Equipo</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="nombre" name="nombre" placeholder="nombre" value="<?php echo e(isset($equipo)? $equipo->nombre :old('nombre')); ?>">
                    <label for="floatingInput">Nombre</label>
                </div>
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="ciudad" name="ciudad" placeholder="ciudad" value="<?php echo e(isset($equipo)? $equipo->ciudad :old('ciudad')); ?>">
                    <label for="floatingInput">Ciudad</label>
                </div>
                <input type="submit" value="Guardar" class="btn btn-primary">
                    <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-danger">Cancelar</a>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ardon\Herd\proyecto_mariachacon\resources\views/equipos/formulario.blade.php ENDPATH**/ ?>