<?php $__env->startSection('titulo', 'Lista de Jugadores'); ?>
<?php $__env->startSection('contenido'); ?>

    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 12px 15px;
            border: 1px solid #090909;
            text-align: center;
        }
    </style>

    <h1>Lista de Jugadores
    </h1>

    <?php if(session()->has('status')): ?>
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            <strong>¡Felicidades! </strong><?php echo e(session('status')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <?php if(count($jugadores) > 0): ?>
        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Edad</th>
                <th>Posición</th>
                <th>Equipo</th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($jugador->id); ?></td>
                    <td>
                        <a href="<?php echo e(route('jugadores.show', ['id' => $jugador->id])); ?>">
                            <?php echo e($jugador->nombre); ?>

                        </a>
                    </td>
                    <td><?php echo e($jugador->edad); ?></td>
                    <td><?php echo e($jugador->posicion); ?></td>
                    <td><?php echo e($jugador->equipo->nombre ?? 'Sin equipo'); ?></td>
                    <td>
                        <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('jugadores.edit', ['id'=> $jugador->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
                        <?php endif; ?>

                        <?php if(auth()->guard()->check()): ?>
                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#eliminar_<?php echo e($jugador->id); ?>">Eliminar</button>
                        <?php endif; ?>

                        <div class="modal fade" id="eliminar_<?php echo e($jugador->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar jugador</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        ¿Desea realmente eliminar el jugador <?php echo e($jugador->nombre); ?>?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                        <form action="<?php echo e(route('jugadores.destroy', ['id'=> $jugador->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <input type="submit" value="Eliminar" class="btn btn-danger btn-sm">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php echo e($jugadores->links()); ?>

    <?php else: ?>
        <p>No hay jugadores registrados.</p>
    <?php endif; ?>

    <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-primary">Volver a Lista de Equipos</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ardon\Herd\proyecto_mariachacon\resources\views/jugadores/index.blade.php ENDPATH**/ ?>