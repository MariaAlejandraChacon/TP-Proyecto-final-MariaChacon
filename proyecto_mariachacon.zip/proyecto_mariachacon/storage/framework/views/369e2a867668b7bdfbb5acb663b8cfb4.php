<?php $__env->startSection('titulo', isset($jugador) ? 'Editar Jugador' : 'Añadir Jugador'); ?>
<?php $__env->startSection('contenido'); ?>

    <h1>
        <?php if(isset($jugador)): ?>
            Editar
        <?php else: ?>
            Añadir
        <?php endif; ?>
        Jugador
    </h1>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <form method="post" action="<?php echo e(isset($jugador) ? route('jugadores.update', ['id' => $jugador->id]) : route('jugadores.store')); ?>">
                        <?php if(isset($jugador)): ?>
                            <?php echo method_field('put'); ?>
                        <?php endif; ?>
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre"
                                   value="<?php echo e(isset($jugador) ? $jugador->nombre : old('nombre')); ?>">
                            <label for="nombre">Nombre del Jugador</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="number" class="form-control" id="edad" name="edad" placeholder="Edad"
                                   value="<?php echo e(isset($jugador) ? $jugador->edad : old('edad')); ?>">
                            <label for="edad">Edad</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="posicion" name="posicion" placeholder="Posición"
                                   value="<?php echo e(isset($jugador) ? $jugador->posicion : old('posicion')); ?>">
                            <label for="posicion">Posición</label>
                        </div>
                        <div class="form-floating mb-3">
                            <select class="form-select" id="equipo_id" name="equipo_id">
                                <option value="">-- Selecciona un equipo --</option>
                                <?php $__currentLoopData = $equipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($equipo->id); ?>"
                                            <?php if((isset($jugador) && $jugador->equipo_id == $equipo->id) || old('equipo_id') == $equipo->id): ?>
                                                selected
                                        <?php endif; ?>
                                    >
                                        <?php echo e($equipo->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="equipo_id">Equipo</label>
                        </div>

                            <button type="submit" class="btn btn-primary"><?php echo e(isset($jugador) ? 'Actualizar' : 'Guardar'); ?></button>
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Cancelar</a>  
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
```

<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ardon\Herd\proyecto_mariachacon\resources\views/jugadores/formulario.blade.php ENDPATH**/ ?>