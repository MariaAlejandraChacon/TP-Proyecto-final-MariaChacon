<?php $__env->startSection('titulo', 'Detalles del Equipo'); ?>

<?php $__env->startSection('contenido'); ?>
    
    <h1>Detalles del Equipo <?php echo e($equipo->nombre); ?></h1>

    <ul>
        <li>ID: <?php echo e($equipo->id); ?></li>
        <li>Código de Equipo: <?php echo e($equipo->equipoCodigo); ?></li>
        <li>Nombre: <?php echo e($equipo->nombre); ?></li>
        <li>Ciudad: <?php echo e($equipo->ciudad); ?></li>
        <li>Fecha de Creación: <?php echo e($equipo->created_at->diffForHumans()); ?></li>
        <li>Fecha de Actualización: <?php echo e($equipo->updated_at->diffForHumans()); ?></li>
    </ul>

    <hr>

    
    <?php echo $__env->make('jugadores.show', ['equipo' => $equipo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-primary">Volver a Lista de Equipos</a>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ardon\Herd\proyecto_mariachacon\resources\views/equipos/show.blade.php ENDPATH**/ ?>