
<h2>Jugadores del Equipo</h2>

<?php if($equipo->jugadores->count() > 0): ?>
    <table class="table">
        <thead>
        <tr>
            <th>Nombre</th>
            <th>Edad</th>
            <th>Posición</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $equipo->jugadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jugador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($jugador->nombre); ?></td>
                <td><?php echo e($jugador->edad); ?></td>
                <td><?php echo e($jugador->posicion); ?></td>
                <td>
                    <a href="<?php echo e(route('jugadores.edit', ['id' => $jugador->id])); ?>" class="btn btn-warning btn-sm">Editar</a>
                    <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#eliminar_<?php echo e($jugador->id); ?>">Eliminar</button>

                    
                    <div class="modal fade" id="eliminar_<?php echo e($jugador->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1 class="modal-title fs-5" id="exampleModalLabel">Eliminar jugador</h1>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    ¿Desea realmente eliminar el jugador <?php echo e($jugador->nombre); ?>?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cerrar</button>
                                    <form action="<?php echo e(route('jugadores.destroy', ['id'=> $jugador->id])); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <input type="submit" value="Eliminar" class="btn btn-danger btn-sm">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p>Este equipo no tiene jugadores registrados.</p>
<?php endif; ?>
<?php /**PATH C:\Users\ardon\Herd\proyecto_mariachacon\resources\views/jugadores/show.blade.php ENDPATH**/ ?>